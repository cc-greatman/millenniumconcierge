<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::group(['namespace' => 'App\Http\Controllers'], function() {

    Route::get('/', 'Controller@index')->name('home');
    Route::get('about', 'Controller@about')->name('about');
    Route::get('services', 'Controller@services')->name('services');
    Route::get('membership', 'Controller@membership')->name('membership');
    Route::get('enquiry', 'Controller@contact')->name('contact');
});
