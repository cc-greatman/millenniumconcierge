<?php echo $__env->make('partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Comming soon -->
<section class="comming section-padding">
    <div class="v-middle">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h1 style="padding-top: 40px;">404</h1>
                    <h2>We Can't Find That Page!</h2>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-6 col-md-12 text-center">
                    <p>The page you are looking for was moved, removed, renamed or never existed.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/u495454642/domains/millenniumconcierge.ng/public_html/resources/views/errors/404.blade.php ENDPATH**/ ?>