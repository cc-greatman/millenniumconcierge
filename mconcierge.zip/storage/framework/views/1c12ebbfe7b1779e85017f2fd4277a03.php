
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <!-- Logo -->
            <div class="logo-wrapper">
                <a class="logo" href="<?php echo e(route('home')); ?>"> <img src="<?php echo e(asset("../frontend/img/logo-light.png")); ?>" class="logo-img" alt=""> </a>
            </div>
            <!-- Button -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar" aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"><i class="ti-menu"></i></span> </button>
            <!-- Menu -->
            <div class="collapse navbar-collapse" id="navbar">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link <?php if(Route::is('home')): ?> active <?php endif; ?>" href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li class="nav-item"><a class="nav-link <?php if(Route::is('about')): ?> active <?php endif; ?>" href="<?php echo e(route('about')); ?>">About</a></li>
                    <li class="nav-item"><a class="nav-link <?php if(Route::is('services')): ?> active <?php endif; ?>" href="<?php echo e(route('services')); ?>">Services</a></li>
                    <li class="nav-item"><a class="nav-link <?php if(Route::is('membership')): ?> active <?php endif; ?>" href="<?php echo e(route('membership')); ?>">Membership</a></li>
                    <li class="nav-item"><a class="nav-link <?php if(Route::is('contact')): ?> active <?php endif; ?>" href="<?php echo e(route('contact')); ?>">Enquiry</a></li>
                </ul>
            </div>
        </div>
    </nav>
<?php /**PATH /home/u212868541/domains/millenniumconcierge.ng/public_html/resources/views/partials/navbar.blade.php ENDPATH**/ ?>