<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    use AuthorizesRequests, ValidatesRequests;

    public function index() {

        $pageTitle = "Home || Millennium Concierge";

        return view('index', compact('pageTitle'));
    }

    public function about() {

        $pageTitle = "About Us || Millennium Concierge";

        return view('about', compact('pageTitle'));
    }

    public function services() {

        $pageTitle = "Our Services || Millennium Concierge";

        return view('services', compact('pageTitle'));
    }

    public function membership() {

        $pageTitle = "Membership || Millennium Concierge";

        return view('membership', compact('pageTitle'));
    }

    public function contact() {

        $pageTitle = "Contact Us || Millennium Concierge";

        return view('enquiry', compact('pageTitle'));
    }
}
