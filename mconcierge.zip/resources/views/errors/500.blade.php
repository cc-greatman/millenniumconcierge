@include('partials.head')

@include('partials.navbar')

<!-- Comming soon -->
<section class="comming section-padding">
    <div class="v-middle">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h1 style="padding-top: 40px;">500</h1>
                    <h2>Server Error!</h2>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-6 col-md-12 text-center">
                    <p>The proccess you made can't be processed at this time.</p>
                </div>
            </div>
        </div>
    </div>
</section>

@include('partials.footer')
